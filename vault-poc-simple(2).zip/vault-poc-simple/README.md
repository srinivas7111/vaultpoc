# Vault POC — Spring Boot Dynamic Database Credentials

## Run

```bash
chmod +x start.sh stop.sh

# Start PostgreSQL + Vault + configure everything + launch the app
./start.sh
```

That's it. The script:
1. Starts PostgreSQL in Podman
2. Starts Vault in Podman (dev mode)
3. Configures the Database Secrets Engine and creates the role
4. Runs `mvn spring-boot:run` — app gets a Vault-issued DB user on startup

## Try it

```bash
# List employees — shows the active Vault-generated DB user
curl http://localhost:8080/employees | jq .

# Create an employee
curl -X POST http://localhost:8080/employees \
  -H "Content-Type: application/json" \
  -d '{"name":"Alice","department":"Engineering"}'
```

## Verify dynamic credentials

```bash
# See the Vault-generated PostgreSQL user currently active
podman exec vault-postgres \
  psql -U vaultadmin -d appdb \
  -c "SELECT usename, valuntil FROM pg_user WHERE usename LIKE 'v-%';"

# Stop the app (Ctrl+C) and restart — a completely new DB user appears
./start.sh
```

## Stop

```bash
./stop.sh       # removes PostgreSQL and Vault containers
# Ctrl+C        # stops the Spring Boot app
```
