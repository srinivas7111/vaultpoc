package com.example.vault;

import jakarta.persistence.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

// ── Entity ────────────────────────────────────────────────────────────────────
@Entity
@Table(name = "employees")
class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    String name;
    String department;

    Employee() {}
    Employee(String name, String department) {
        this.name = name;
        this.department = department;
    }
}

// ── Repository ────────────────────────────────────────────────────────────────
@Repository
interface EmployeeRepository extends JpaRepository<Employee, Long> {}

// ── Controller ────────────────────────────────────────────────────────────────
@RestController
@RequestMapping("/employees")
class EmployeeController {

    private final EmployeeRepository repo;

    // Vault injects this via spring.datasource.username — shows the dynamic DB user
    @Value("${spring.datasource.username:unknown}")
    private String activeDbUser;

    EmployeeController(EmployeeRepository repo) {
        this.repo = repo;
    }

    // GET /employees — list all, shows which Vault-issued DB user ran the query
    @GetMapping
    Map<String, Object> list() {
        return Map.of(
            "vault_db_user", activeDbUser,   // e.g. v-token-app-role-AbCdEf-1234567890
            "employees",     repo.findAll()
        );
    }

    // POST /employees — create one
    @PostMapping
    Employee create(@RequestBody Employee e) {
        return repo.save(e);
    }

    // DELETE /employees/{id}
    @DeleteMapping("/{id}")
    void delete(@PathVariable Long id) {
        repo.deleteById(id);
    }
}
