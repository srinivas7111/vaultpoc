package com.example.vault;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VaultPocApplication {
    public static void main(String[] args) {
        SpringApplication.run(VaultPocApplication.class, args);
    }
}
