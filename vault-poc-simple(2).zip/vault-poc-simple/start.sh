#!/bin/bash
set -e

echo "============================================"
echo "  Vault POC — Starting Infrastructure"
echo "============================================"

# ── 1. Start PostgreSQL ───────────────────────────────────────────
echo ""
echo "[1/4] Starting PostgreSQL..."
podman rm -f vault-postgres 2>/dev/null || true
podman run -d \
  --name vault-postgres \
  -e POSTGRES_DB=appdb \
  -e POSTGRES_USER=vaultadmin \
  -e POSTGRES_PASSWORD=vaultadminpass \
  -p 5432:5432 \
  docker.io/postgres:15-alpine

# Wait for PostgreSQL to be ready
echo "      Waiting for PostgreSQL..."
until podman exec vault-postgres pg_isready -U vaultadmin -d appdb > /dev/null 2>&1; do
  sleep 2
done
echo "      PostgreSQL ready."

# ── 2. Start Vault (dev mode) ─────────────────────────────────────
echo ""
echo "[2/4] Starting Vault..."
podman rm -f vault-server 2>/dev/null || true
podman run -d \
  --name vault-server \
  -e VAULT_DEV_ROOT_TOKEN_ID=root \
  -e VAULT_DEV_LISTEN_ADDRESS=0.0.0.0:8200 \
  -p 8200:8200 \
  docker.io/hashicorp/vault:1.15 \
  vault server -dev

# Wait for Vault to be ready
echo "      Waiting for Vault..."
until curl -sf http://localhost:8200/v1/sys/health > /dev/null 2>&1; do
  sleep 2
done
echo "      Vault ready."

# ── 3. Configure Vault ────────────────────────────────────────────
echo ""
echo "[3/4] Configuring Vault Database Secrets Engine..."

export VAULT_ADDR=http://localhost:8200
export VAULT_TOKEN=root

# Get the host IP that Vault container can use to reach PostgreSQL
# (Vault runs in a container, PostgreSQL is also a container — use host network IP)
POSTGRES_HOST=$(hostname -I | awk '{print $1}')
echo "      Using host IP for Vault→Postgres connection: $POSTGRES_HOST"

# Enable the database secrets engine
vault secrets enable database 2>/dev/null || echo "      (already enabled)"

# Configure the PostgreSQL connection
vault write database/config/postgresql \
  plugin_name=postgresql-database-plugin \
  allowed_roles="app-role" \
  connection_url="postgresql://{{username}}:{{password}}@${POSTGRES_HOST}:5432/appdb?sslmode=disable" \
  username="vaultadmin" \
  password="vaultadminpass"

# Create the role — Vault uses creation_statements to make a dynamic DB user
vault write database/roles/app-role \
  db_name=postgresql \
  creation_statements="
    CREATE ROLE \"{{name}}\" WITH LOGIN PASSWORD '{{password}}' VALID UNTIL '{{expiration}}';
    GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO \"{{name}}\";
    GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO \"{{name}}\";
    GRANT USAGE ON SCHEMA public TO \"{{name}}\";
  " \
  revocation_statements="DROP ROLE IF EXISTS \"{{name}}\";" \
  default_ttl="1h" \
  max_ttl="24h"

echo ""
echo "      Verifying — requesting a test credential:"
vault read database/creds/app-role
echo ""
echo "      Vault configured."

# ── 4. Start Spring Boot ──────────────────────────────────────────
echo ""
echo "[4/4] Starting Spring Boot app..."
echo "      App will be available at http://localhost:8080/employees"
echo ""
mvn spring-boot:run
