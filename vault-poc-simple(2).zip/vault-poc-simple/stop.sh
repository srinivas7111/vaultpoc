#!/bin/bash

echo "Stopping Vault POC..."
podman rm -f vault-postgres vault-server 2>/dev/null || true
echo "Done — PostgreSQL and Vault stopped."
