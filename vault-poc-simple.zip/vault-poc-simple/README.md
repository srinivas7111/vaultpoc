# Vault POC — Spring Boot Dynamic Database Credentials

Spring Boot app that gets a **unique, short-lived PostgreSQL user from Vault** on every startup.
No passwords in config files, environment variables, or code.

## Run it

```bash
# 1. Start Postgres + Vault + configure the DB secrets engine
docker-compose up -d

# Wait ~5 seconds for vault-setup to finish, then check:
docker logs vault-poc-simple-vault-setup-1

# 2. Start the Spring Boot app
mvn spring-boot:run
```

On startup you'll see Vault generate a DB user like `v-token-app-role-AbCdEf-1234567890`.
**Restart the app — you get a completely different user every time.**

## Try it

```bash
# List employees — response includes which Vault DB user ran the query
curl http://localhost:8080/employees | jq .

# {
#   "vault_db_user": "v-token-app-role-WxYzAbCd-9876543210",
#   "employees": []
# }

# Create an employee
curl -X POST http://localhost:8080/employees \
  -H "Content-Type: application/json" \
  -d '{"name":"Alice","department":"Engineering"}'

# Check which DB users Vault has created in PostgreSQL right now
docker exec vault-poc-simple-postgres-1 \
  psql -U vaultadmin -d appdb -c \
  "SELECT usename, valuntil FROM pg_user WHERE usename LIKE 'v-%';"
```

## How it works

```
App startup
  └─► Spring Cloud Vault calls GET /v1/database/creds/app-role
        └─► Vault runs: CREATE ROLE "v-token-app-role-..." WITH LOGIN ...
              └─► Returns username + password + lease_id
                    └─► Spring injects into spring.datasource.username/password
                          └─► HikariCP opens pool with those credentials
                                └─► Lease auto-renewed at 70% TTL
                                      └─► On shutdown: DROP ROLE immediately
```

## What's in the code

| File | Purpose |
|---|---|
| `bootstrap.yml` | Vault connection + tells Spring Cloud Vault to call `database/creds/app-role` |
| `EmployeeApp.java` | Entity + Repository + Controller — all in one file |
| `docker/vault-setup.sh` | Enables DB secrets engine, connects to Postgres, creates the role |
| `docker-compose.yml` | Postgres + Vault dev mode + one-shot setup container |
