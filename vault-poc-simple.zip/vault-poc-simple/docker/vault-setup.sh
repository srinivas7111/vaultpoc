#!/bin/sh
# Wait for Vault to be ready
echo "Waiting for Vault..."
until vault status > /dev/null 2>&1; do sleep 2; done
echo "Vault ready."

# 1. Enable the database secrets engine
vault secrets enable database

# 2. Connect Vault to PostgreSQL
#    Vault uses vaultadmin to CREATE and DROP dynamic users
vault write database/config/postgresql \
    plugin_name=postgresql-database-plugin \
    allowed_roles="app-role" \
    connection_url="postgresql://{{username}}:{{password}}@postgres:5432/appdb?sslmode=disable" \
    username="vaultadmin" \
    password="vaultadminpass"

# 3. Create the role
#    Vault runs creation_statements when an app requests credentials.
#    {{name}}, {{password}}, {{expiration}} are filled in by Vault.
vault write database/roles/app-role \
    db_name=postgresql \
    creation_statements="
        CREATE ROLE \"{{name}}\" WITH LOGIN PASSWORD '{{password}}' VALID UNTIL '{{expiration}}';
        GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO \"{{name}}\";
        GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO \"{{name}}\";
        GRANT USAGE ON SCHEMA public TO \"{{name}}\";
    " \
    revocation_statements="DROP ROLE IF EXISTS \"{{name}}\";" \
    default_ttl="1h" \
    max_ttl="24h"

echo ""
echo "Done. Test it:"
vault read database/creds/app-role
