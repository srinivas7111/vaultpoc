# Vault POC — Spring Boot Dynamic Database Credentials

A working Spring Boot application demonstrating **HashiCorp Vault Database Secrets Engine**
for dynamic, short-lived database credentials. No static passwords anywhere.

---

## What This POC Demonstrates

| Concept | What You'll See |
|---|---|
| **Dynamic credentials** | Every app startup gets a unique PostgreSQL user (e.g. `v-token-readon-AbCdEf-1234`) |
| **Automatic TTL expiry** | DB user is dropped after 60 seconds (demo TTL) — no manual cleanup |
| **Lease renewal** | Spring Cloud Vault renews the lease at 70% TTL automatically |
| **Immediate revocation** | On shutdown, the DB user is dropped instantly |
| **Least privilege** | `readonly-role` → SELECT only. `readwrite-role` → full DML. Enforced at the DB layer. |
| **Zero static secrets** | No passwords in `application.yml`, environment variables, or config files |

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                        Spring Boot App                              │
│                                                                     │
│  startup                                                            │
│    │                                                                │
│    ▼                                                                │
│  Spring Cloud Vault ──► GET /v1/database/creds/readonly-role ──►   │
│                                        │                            │
│                              ┌─────────▼──────────┐                │
│                              │   HashiCorp Vault   │                │
│                              │  Database Secrets   │                │
│                              │      Engine         │                │
│                              └─────────┬──────────┘                │
│                                        │ CREATE ROLE v-token-... LOGIN │
│                                        ▼                            │
│                              ┌─────────────────────┐               │
│                              │     PostgreSQL       │               │
│                              │  (appdb database)    │               │
│                              └─────────────────────┘               │
│                                        │                            │
│  Vault returns: username + password + lease_id + TTL               │
│    │                                                                │
│    ▼                                                                │
│  HikariCP connection pool opens with Vault credentials             │
│    │                                                                │
│    ▼                                                                │
│  App queries run as Vault-generated DB user                        │
│    │                                                                │
│    ▼  (at 70% TTL)                                                 │
│  Spring Cloud Vault renews lease ──► Vault extends TTL             │
│    │                                                                │
│    ▼  (on shutdown or TTL expiry)                                  │
│  Vault drops the PostgreSQL user ──► DB user no longer exists      │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Project Structure

```
vault-poc/
├── pom.xml                                         # Spring Boot + Spring Cloud Vault deps
├── docker-compose.yml                              # PostgreSQL + Vault + setup container
├── docker/
│   ├── init.sql                                    # DB schema + seed data
│   └── vault-setup.sh                              # Configures DB secrets engine & roles
└── src/main/
    ├── resources/
    │   ├── bootstrap.yml                           # Vault connection + DB secrets engine config
    │   └── application.yml                         # App config
    └── java/com/example/vaultpoc/
        ├── VaultPocApplication.java                # Entry point
        ├── config/
        │   └── VaultConfig.java                    # Logs active credentials on startup
        ├── model/
        │   └── Employee.java                       # JPA entity
        ├── service/
        │   ├── EmployeeRepository.java             # JPA repository
        │   └── VaultCredentialService.java         # Direct Vault API operations
        └── controller/
            ├── EmployeeController.java             # DB query endpoints
            └── VaultController.java                # Vault lease management endpoints
```

---

## Quick Start

### Prerequisites
- Docker + Docker Compose
- Java 17+
- Maven 3.8+

### Step 1 — Start Infrastructure

```bash
# Start PostgreSQL + Vault (dev mode) + run Vault setup
docker-compose up -d

# Wait ~10 seconds for Vault setup to complete, then check:
docker logs vault-poc-setup
```

You should see:
```
[1/5] Enabling database secrets engine at path: database/
[2/5] Configuring PostgreSQL connection...
[3/5] Creating readonly-role (TTL: 60s for demo)...
[4/5] Creating readwrite-role...
[5/5] Creating app-policy...
Testing dynamic credential generation for readonly-role:
Key                Value
---                -----
lease_id           database/creds/readonly-role/AbCdEfGhIj...
lease_duration     1m
username           v-token-readon-AbCdEfGhIj-1234567890
password           A1B2-C3D4-E5F6-...
```

### Step 2 — Start the Spring Boot App

```bash
mvn spring-boot:run
```

Watch the startup logs — you'll see:

```
═══════════════════════════════════════════════════════════
  VAULT POC — Dynamic Database Credentials
═══════════════════════════════════════════════════════════
  Datasource URL  : jdbc:postgresql://localhost:5432/appdb
  DB Username     : v-token-readon-WxYzAbCd-1234567890   ← unique per startup
  DB Password     : [hidden — injected by Spring Cloud Vault]
═══════════════════════════════════════════════════════════
  No static credentials anywhere in code or config files.
  Vault will auto-revoke this DB user when the lease expires.
═══════════════════════════════════════════════════════════
```

**Stop and restart the app** — you'll get a completely different DB username every time.

---

## API Reference & curl Examples

### Employee Endpoints (run via Vault credentials)

```bash
# List all employees — note the active_vault_db_user in the response
curl -s http://localhost:8080/api/employees | jq .

# Response:
# {
#   "active_vault_db_user": "v-token-readon-WxYzAbCd-1234567890",
#   "count": 8,
#   "employees": [...],
#   "note": "This query ran as a Vault-generated DB user with SELECT-only access"
# }

# Get a single employee
curl -s http://localhost:8080/api/employees/1 | jq .

# Filter by department
curl -s http://localhost:8080/api/employees/department/Engineering | jq .

# Attempt a write with readonly-role — Vault enforces least privilege at the DB layer
curl -s -X POST http://localhost:8080/api/employees \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","department":"QA","salary":70000}' | jq .

# Response (with readonly-role):
# {
#   "error": "Permission denied by PostgreSQL",
#   "active_vault_db_user": "v-token-readon-...",
#   "detail": "The Vault role 'readonly-role' only grants SELECT. Use 'readwrite-role' for writes.",
#   "vault_enforced": true
# }
```

### Vault Credential Endpoints (POC observability)

```bash
# Request a fresh dynamic credential — Vault creates a new PostgreSQL user
curl -s http://localhost:8080/api/vault/credentials/readonly-role | jq .

# Response:
# {
#   "username": "v-token-readon-AbCdEfGh-9876543210",
#   "password": "***masked***",
#   "lease_id": "database/creds/readonly-role/AbCdEfGhIjKlMnOpQr",
#   "lease_duration_seconds": 60,
#   "renewable": true
# }

# Confirm the user exists in PostgreSQL right now:
docker exec vault-poc-postgres psql -U vaultadmin -d appdb \
  -c "SELECT usename, valuntil FROM pg_user WHERE usename LIKE 'v-%';"

# Renew a lease (extend the TTL)
LEASE_ID="database/creds/readonly-role/AbCdEfGhIjKlMnOpQr"
curl -s -X POST "http://localhost:8080/api/vault/lease/$(python3 -c "import urllib.parse; print(urllib.parse.quote('$LEASE_ID', safe=''))")/renew" \
  -H "Content-Type: application/json" \
  -d '{"increment_seconds": 120}' | jq .

# Immediately revoke a lease — DB user is dropped in PostgreSQL instantly
curl -s -X DELETE "http://localhost:8080/api/vault/lease/$(python3 -c "import urllib.parse; print(urllib.parse.quote('$LEASE_ID', safe=''))")" | jq .

# Confirm user is gone from PostgreSQL:
docker exec vault-poc-postgres psql -U vaultadmin -d appdb \
  -c "SELECT usename FROM pg_user WHERE usename LIKE 'v-%';"
```

### Direct Vault CLI Commands (from host)

```bash
# Set Vault address
export VAULT_ADDR=http://localhost:8200
export VAULT_TOKEN=root

# Generate a credential manually
vault read database/creds/readonly-role

# List all active leases for the DB secrets engine
vault list sys/leases/lookup/database/creds/readonly-role

# Revoke all credentials for a role (emergency revocation)
vault lease revoke -prefix database/creds/readonly-role

# See the DB secrets engine config
vault read database/config/postgresql

# Check what roles are configured
vault list database/roles
vault read database/roles/readonly-role
```

### Verify in PostgreSQL

```bash
# See all Vault-generated users currently active in PostgreSQL
docker exec vault-poc-postgres psql -U vaultadmin -d appdb \
  -c "SELECT usename, valuntil FROM pg_user WHERE usename LIKE 'v-%' ORDER BY valuntil;"

# See what permissions the Vault user has
docker exec vault-poc-postgres psql -U vaultadmin -d appdb \
  -c "\dp employees"

# Wait 60 seconds and run again — users will be gone (TTL expired)
```

---

## Key Configuration Explained

### bootstrap.yml — Database Secrets Engine

```yaml
spring:
  cloud:
    vault:
      database:
        enabled: true
        role: readonly-role          # Which Vault role to request credentials from
        backend: database            # Mount path of the secrets engine
        username-property: spring.datasource.username  # Where to inject the username
        password-property: spring.datasource.password  # Where to inject the password
      config:
        lifecycle:
          enabled: true             # Enable automatic lease renewal
          min-renewal: 10s          # Minimum time before renewal attempt
          expiry-threshold: 10s     # Renew if expiry is within this threshold
```

### Vault Role — creation_statements

The `creation_statements` in `vault-setup.sh` define exactly what PostgreSQL permissions
each dynamic user gets. This is where least-privilege is enforced:

```sql
-- readonly-role: SELECT only
CREATE ROLE "{{name}}" WITH LOGIN PASSWORD '{{password}}' VALID UNTIL '{{expiration}}';
GRANT SELECT ON ALL TABLES IN SCHEMA public TO "{{name}}";

-- readwrite-role: full DML
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO "{{name}}";
```

Vault substitutes `{{name}}`, `{{password}}`, and `{{expiration}}` at credential generation time.

---

## POC Scenarios to Run

### Scenario 1 — Watch credentials change on restart
```bash
# Start app, note the DB username in logs
mvn spring-boot:run

# Stop (Ctrl+C) — Vault revokes the DB user immediately
# Restart — a completely different DB username appears
mvn spring-boot:run
```

### Scenario 2 — TTL expiry in real time
```bash
# Request a credential (60s TTL)
curl -s http://localhost:8080/api/vault/credentials/readonly-role | jq .username

# Check the user in PostgreSQL — it exists
docker exec vault-poc-postgres psql -U vaultadmin -d appdb \
  -c "SELECT usename, valuntil FROM pg_user WHERE usename LIKE 'v-%';"

# Wait 65 seconds...
sleep 65

# Check again — user is gone
docker exec vault-poc-postgres psql -U vaultadmin -d appdb \
  -c "SELECT usename, valuntil FROM pg_user WHERE usename LIKE 'v-%';"
```

### Scenario 3 — Least privilege enforcement
```bash
# With readonly-role — write attempt rejected at DB level
curl -s -X POST http://localhost:8080/api/employees \
  -H "Content-Type: application/json" \
  -d '{"name":"Test","department":"QA","salary":70000}' | jq .error
```

### Scenario 4 — Emergency credential revocation
```bash
# Simulate breach: revoke ALL credentials for a role instantly
export VAULT_ADDR=http://localhost:8200
export VAULT_TOKEN=root
vault lease revoke -prefix database/creds/readonly-role

# All v-token-readon-* users dropped from PostgreSQL immediately
# App will fail on next DB query — this is the expected behaviour
```

---

## Production Considerations

| POC Setting | Production Recommendation |
|---|---|
| `authentication: TOKEN` | Use Kubernetes SA, AWS IAM, or AppRole with wrapped Secret ID |
| `scheme: http` | Use `https` with a valid TLS certificate |
| `default_ttl: 60s` | Use `1h` or longer with lease renewal enabled |
| `VAULT_TOKEN=root` | Use a least-privilege token from a proper auth method |
| Vault dev mode | Deploy 3-node Raft HA cluster with KMS auto-unseal |
| Single role | Separate roles per service with distinct permission sets |
| Manual root password | Rotate with `vault write -force database/rotate-root/postgresql` |
