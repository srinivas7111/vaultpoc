-- docker/init.sql
-- Runs once when the PostgreSQL container first starts.
-- Creates the schema and seeds test data.

-- ── Schema ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS employees (
    id         BIGSERIAL PRIMARY KEY,
    name       VARCHAR(255) NOT NULL,
    department VARCHAR(255) NOT NULL,
    salary     NUMERIC(12, 2)
);

-- ── Seed data ───────────────────────────────────────────────────────────────
INSERT INTO employees (name, department, salary) VALUES
    ('Alice Johnson',  'Engineering',  95000.00),
    ('Bob Smith',      'Engineering',  88000.00),
    ('Carol White',    'Product',      92000.00),
    ('David Brown',    'Finance',      78000.00),
    ('Eve Davis',      'Engineering',  105000.00),
    ('Frank Miller',   'HR',           72000.00),
    ('Grace Wilson',   'Product',      89000.00),
    ('Henry Taylor',   'Finance',      81000.00);

-- ── Grant vaultadmin permission to create/drop roles ───────────────────────
-- Vault uses the vaultadmin superuser to CREATE ROLE and DROP ROLE
-- when issuing and revoking dynamic credentials.
GRANT ALL PRIVILEGES ON DATABASE appdb TO vaultadmin;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO vaultadmin;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO vaultadmin;
ALTER USER vaultadmin CREATEROLE;
