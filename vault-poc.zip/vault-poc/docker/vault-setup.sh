#!/bin/sh
# docker/vault-setup.sh
# Configures the Vault Database Secrets Engine for the POC.
# Runs once in a one-shot container after Vault starts.

set -e

echo "═══════════════════════════════════════════════════════"
echo "  Vault POC Setup — Configuring Database Secrets Engine"
echo "═══════════════════════════════════════════════════════"

# Wait for Vault to be ready
echo "Waiting for Vault to start..."
until vault status > /dev/null 2>&1; do
  sleep 2
done
echo "Vault is ready."

# ── Step 1: Enable the Database Secrets Engine ─────────────────────────────
echo ""
echo "[1/5] Enabling database secrets engine at path: database/"
vault secrets enable database || echo "  (already enabled)"

# ── Step 2: Configure the PostgreSQL connection ────────────────────────────
# Vault uses vaultadmin to connect to PostgreSQL and CREATE/DROP dynamic users.
echo ""
echo "[2/5] Configuring PostgreSQL connection (vault manages lifecycle)..."
vault write database/config/postgresql \
    plugin_name=postgresql-database-plugin \
    allowed_roles="readonly-role,readwrite-role" \
    connection_url="postgresql://{{username}}:{{password}}@postgres:5432/appdb?sslmode=disable" \
    username="vaultadmin" \
    password="vaultadminpass"

echo "  PostgreSQL connection configured."

# ── Step 3: Rotate the root credential ────────────────────────────────────
# Best practice: rotate the root password immediately after configuration.
# Vault will manage the vaultadmin password going forward.
# (Skipped in dev mode POC for simplicity — enable in production)
# vault write -force database/rotate-root/postgresql

# ── Step 4: Create the READ-ONLY role ─────────────────────────────────────
# Vault will execute creation_statements when generating credentials.
# The {{name}} and {{password}} are placeholders Vault fills in.
# default_ttl: credential lifetime (60s for fast POC demo — use 1h in production)
# max_ttl:     maximum renewable lifetime
echo ""
echo "[3/5] Creating readonly-role (TTL: 60s for demo, use 1h in production)..."
vault write database/roles/readonly-role \
    db_name=postgresql \
    creation_statements="
        CREATE ROLE \"{{name}}\" WITH LOGIN PASSWORD '{{password}}' VALID UNTIL '{{expiration}}';
        GRANT SELECT ON ALL TABLES IN SCHEMA public TO \"{{name}}\";
        GRANT USAGE ON SCHEMA public TO \"{{name}}\";
    " \
    revocation_statements="
        REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA public FROM \"{{name}}\";
        REVOKE USAGE ON SCHEMA public FROM \"{{name}}\";
        DROP ROLE IF EXISTS \"{{name}}\";
    " \
    default_ttl="60s" \
    max_ttl="1h"

echo "  readonly-role created."

# ── Step 5: Create the READ-WRITE role ────────────────────────────────────
echo ""
echo "[4/5] Creating readwrite-role..."
vault write database/roles/readwrite-role \
    db_name=postgresql \
    creation_statements="
        CREATE ROLE \"{{name}}\" WITH LOGIN PASSWORD '{{password}}' VALID UNTIL '{{expiration}}';
        GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO \"{{name}}\";
        GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO \"{{name}}\";
        GRANT USAGE ON SCHEMA public TO \"{{name}}\";
    " \
    revocation_statements="
        REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA public FROM \"{{name}}\";
        REVOKE ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public FROM \"{{name}}\";
        REVOKE USAGE ON SCHEMA public FROM \"{{name}}\";
        DROP ROLE IF EXISTS \"{{name}}\";
    " \
    default_ttl="5m" \
    max_ttl="1h"

echo "  readwrite-role created."

# ── Step 6: Create a Vault policy for the app ─────────────────────────────
echo ""
echo "[5/5] Creating app-policy (least privilege)..."
vault policy write app-policy - <<EOF
# Allow the app to read dynamic DB credentials for both roles
path "database/creds/readonly-role" {
  capabilities = ["read"]
}

path "database/creds/readwrite-role" {
  capabilities = ["read"]
}

# Allow the app to renew its own leases
path "sys/leases/renew" {
  capabilities = ["update"]
}

# Allow the app to revoke its own leases on shutdown
path "sys/leases/revoke" {
  capabilities = ["update"]
}

# Allow lease lookup
path "sys/leases/lookup" {
  capabilities = ["update"]
}
EOF

echo "  app-policy created."

# ── Verification ────────────────────────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════════════════"
echo "  Vault Setup Complete. Verifying..."
echo "═══════════════════════════════════════════════════════"
echo ""
echo "Testing dynamic credential generation for readonly-role:"
vault read database/creds/readonly-role
echo ""
echo "Database secrets engine roles:"
vault list database/roles
echo ""
echo "  Setup done. Spring Boot app can now start."
echo "═══════════════════════════════════════════════════════"
