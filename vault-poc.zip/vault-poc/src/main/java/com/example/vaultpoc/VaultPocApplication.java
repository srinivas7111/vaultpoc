package com.example.vaultpoc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Vault POC — Spring Boot application demonstrating dynamic database credentials
 * via HashiCorp Vault's Database Secrets Engine.
 *
 * How it works:
 *  1. On startup Spring Cloud Vault calls GET /v1/database/creds/{role}
 *  2. Vault generates a unique, short-lived PostgreSQL user (e.g. v-token-readon-xxxx)
 *  3. The username + password are injected into spring.datasource.*
 *  4. HikariCP opens the connection pool with those credentials
 *  5. Spring Cloud Vault automatically renews the lease at 70% TTL
 *  6. On application shutdown, the lease (and the DB user) is revoked immediately
 */
@SpringBootApplication
public class VaultPocApplication {

    public static void main(String[] args) {
        SpringApplication.run(VaultPocApplication.class, args);
    }
}
