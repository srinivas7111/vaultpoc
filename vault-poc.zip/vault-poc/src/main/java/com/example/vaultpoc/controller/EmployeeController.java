package com.example.vaultpoc.controller;

import com.example.vaultpoc.model.Employee;
import com.example.vaultpoc.service.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * EmployeeController — demonstrates real DB queries running against PostgreSQL
 * using Vault-issued dynamic credentials.
 *
 * The datasource was wired with Vault credentials at startup.
 * Every query here runs as the Vault-generated PostgreSQL user.
 */
@Slf4j
@RestController
@RequestMapping("/api/employees")
@RequiredArgsConstructor
public class EmployeeController {

    private final EmployeeRepository employeeRepository;

    // Vault-injected username — injected from spring.datasource.username
    // which was set by Spring Cloud Vault. Shows which DB user is active.
    @Value("${spring.datasource.username:unknown}")
    private String activeDbUsername;

    /**
     * GET /api/employees
     * List all employees — runs as the Vault-generated DB user.
     */
    @GetMapping
    public ResponseEntity<Map<String, Object>> getAllEmployees() {
        List<Employee> employees = employeeRepository.findAll();

        log.info("Queried {} employees using Vault-issued DB user: {}", employees.size(), activeDbUsername);

        return ResponseEntity.ok(Map.of(
                "active_vault_db_user", activeDbUsername,
                "count", employees.size(),
                "employees", employees,
                "note", "This query ran as a Vault-generated DB user with SELECT-only access"
        ));
    }

    /**
     * GET /api/employees/{id}
     * Get a single employee by ID.
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getEmployee(@PathVariable Long id) {
        return employeeRepository.findById(id)
                .map(emp -> ResponseEntity.ok(Map.of(
                        "active_vault_db_user", activeDbUsername,
                        "employee", emp
                )))
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * GET /api/employees/department/{dept}
     * Filter employees by department.
     */
    @GetMapping("/department/{dept}")
    public ResponseEntity<Map<String, Object>> getByDepartment(@PathVariable String dept) {
        List<Employee> employees = employeeRepository.findByDepartment(dept);
        return ResponseEntity.ok(Map.of(
                "active_vault_db_user", activeDbUsername,
                "department", dept,
                "count", employees.size(),
                "employees", employees
        ));
    }

    /**
     * POST /api/employees
     * Create an employee — will FAIL if the Vault role only has SELECT access.
     * This demonstrates least-privilege enforcement at the DB level.
     */
    @PostMapping
    public ResponseEntity<?> createEmployee(@RequestBody Employee employee) {
        try {
            Employee saved = employeeRepository.save(employee);
            log.info("Employee created (write-role used): {}", saved.getId());
            return ResponseEntity.ok(Map.of(
                    "active_vault_db_user", activeDbUsername,
                    "employee", saved,
                    "note", "Write succeeded — DB user has INSERT permission"
            ));
        } catch (Exception e) {
            // Expected if readonly-role is used — Vault enforces least privilege at the DB layer
            log.warn("Write rejected by PostgreSQL for Vault user {}: {}", activeDbUsername, e.getMessage());
            return ResponseEntity.status(403).body(Map.of(
                    "error", "Permission denied by PostgreSQL",
                    "active_vault_db_user", activeDbUsername,
                    "detail", "The Vault role 'readonly-role' only grants SELECT. Use 'readwrite-role' for writes.",
                    "vault_enforced", true
            ));
        }
    }
}
