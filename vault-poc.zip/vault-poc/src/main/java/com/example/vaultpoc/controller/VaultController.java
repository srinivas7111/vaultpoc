package com.example.vaultpoc.controller;

import com.example.vaultpoc.service.VaultCredentialService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * VaultController — exposes REST endpoints to demonstrate Vault
 * Dynamic Database Credential operations directly.
 *
 * These endpoints are for POC/demo purposes only.
 * In production, Spring Cloud Vault handles all of this automatically.
 *
 * Endpoints:
 *   GET  /api/vault/credentials/{role}          → request new dynamic cred
 *   GET  /api/vault/lease/{leaseId}             → inspect lease metadata
 *   POST /api/vault/lease/{leaseId}/renew       → manually renew a lease
 *   DELETE /api/vault/lease/{leaseId}           → immediately revoke a lease
 */
@Slf4j
@RestController
@RequestMapping("/api/vault")
@RequiredArgsConstructor
public class VaultController {

    private final VaultCredentialService vaultCredentialService;

    /**
     * GET /api/vault/credentials/{role}
     *
     * Request a brand-new dynamic DB credential from Vault.
     * Vault generates a unique PostgreSQL user and returns:
     *   - username  (e.g. v-token-readon-AbCdEfGhIj-1234567890)
     *   - password  (random, masked in response)
     *   - lease_id  (used to renew or revoke)
     *   - lease_duration_seconds
     *
     * Example:
     *   GET /api/vault/credentials/readonly-role
     *   GET /api/vault/credentials/readwrite-role
     */
    @GetMapping("/credentials/{role}")
    public ResponseEntity<Map<String, Object>> getCredentials(@PathVariable String role) {
        Map<String, Object> credentials = vaultCredentialService.requestDynamicCredential(role);
        return ResponseEntity.ok(credentials);
    }

    /**
     * GET /api/vault/lease/{leaseId}
     *
     * Inspect the metadata of an active lease without renewing it.
     * Returns: issue_time, expire_time, remaining TTL, renewable flag.
     *
     * Example:
     *   GET /api/vault/lease/database%2Fcreds%2Freadonly-role%2FAbCdEf...
     *   (URL-encode the lease ID — it contains slashes)
     */
    @GetMapping("/lease/{leaseId}")
    public ResponseEntity<Map<String, Object>> getLease(@PathVariable String leaseId) {
        Map<String, Object> leaseInfo = vaultCredentialService.lookupLease(leaseId);
        return ResponseEntity.ok(leaseInfo);
    }

    /**
     * POST /api/vault/lease/{leaseId}/renew
     *
     * Manually renew a lease to extend the DB user's lifetime.
     * Spring Cloud Vault does this automatically at 70% TTL —
     * this endpoint makes it observable for the POC.
     *
     * Request body (optional):
     *   { "increment_seconds": 300 }
     *
     * Example:
     *   POST /api/vault/lease/database%2Fcreds%2Freadonly-role%2FAbCdEf.../renew
     */
    @PostMapping("/lease/{leaseId}/renew")
    public ResponseEntity<Map<String, Object>> renewLease(
            @PathVariable String leaseId,
            @RequestBody(required = false) Map<String, Object> body) {

        int increment = (body != null && body.containsKey("increment_seconds"))
                ? (Integer) body.get("increment_seconds")
                : 300;

        Map<String, Object> result = vaultCredentialService.renewLease(leaseId, increment);
        return ResponseEntity.ok(result);
    }

    /**
     * DELETE /api/vault/lease/{leaseId}
     *
     * Immediately revoke a lease and drop the PostgreSQL user.
     * This simulates what happens on application shutdown or TTL expiry.
     *
     * After calling this:
     *  - The DB user no longer exists in PostgreSQL
     *  - Any open connections using that user will fail
     *
     * Example:
     *   DELETE /api/vault/lease/database%2Fcreds%2Freadonly-role%2FAbCdEf...
     */
    @DeleteMapping("/lease/{leaseId}")
    public ResponseEntity<Map<String, Object>> revokeLease(@PathVariable String leaseId) {
        Map<String, Object> result = vaultCredentialService.revokeLease(leaseId);
        return ResponseEntity.ok(result);
    }
}
