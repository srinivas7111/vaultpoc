package com.example.vaultpoc.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.vault.core.VaultTemplate;
import org.springframework.vault.support.VaultResponseSupport;

import java.util.HashMap;
import java.util.Map;

/**
 * VaultCredentialService demonstrates direct interaction with the
 * Vault Database Secrets Engine for the POC's /api/vault/* endpoints.
 *
 * Key operations shown:
 *  1. Request a new dynamic credential (lease)
 *  2. Renew an existing lease
 *  3. Revoke a lease immediately
 *  4. Inspect lease metadata
 *
 * In a production app you would let Spring Cloud Vault manage this
 * automatically — this service exists only to make the POC observable.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class VaultCredentialService {

    private final VaultTemplate vaultTemplate;

    // ── 1. Request a new dynamic credential ────────────────────────────────

    /**
     * Calls GET /v1/database/creds/{role} to generate a fresh DB user.
     *
     * Vault creates a PostgreSQL user with a name like:
     *   v-token-readonly-role-AbCdEfGhIjKlMn-1234567890
     *
     * The user is automatically dropped when the lease expires.
     *
     * @param role Vault database role name (e.g. "readonly-role")
     * @return Map containing username, password, lease_id, lease_duration
     */
    public Map<String, Object> requestDynamicCredential(String role) {
        log.info("Requesting dynamic credential for role: {}", role);

        VaultResponseSupport<Map> response = vaultTemplate.read(
                "database/creds/" + role, Map.class
        );

        if (response == null || response.getData() == null) {
            throw new RuntimeException("No response from Vault for role: " + role);
        }

        Map<String, Object> result = new HashMap<>(response.getData());
        result.put("lease_id", response.getLeaseId());
        result.put("lease_duration_seconds", response.getLeaseDuration());
        result.put("renewable", response.isRenewable());

        log.info("Vault issued new DB user: {} | lease: {} | TTL: {}s",
                result.get("username"),
                result.get("lease_id"),
                result.get("lease_duration_seconds"));

        // Mask password in logs — never log plaintext credentials in production
        result.put("password", "***masked***");
        return result;
    }

    // ── 2. Renew a lease ────────────────────────────────────────────────────

    /**
     * Calls POST /v1/sys/leases/renew to extend the TTL of an active lease.
     *
     * Spring Cloud Vault does this automatically at 70% TTL.
     * This endpoint lets you trigger renewal manually for the POC.
     *
     * @param leaseId The full lease ID (e.g. "database/creds/readonly-role/AbCdEf...")
     * @param incrementSeconds How many seconds to extend the TTL by
     */
    public Map<String, Object> renewLease(String leaseId, int incrementSeconds) {
        log.info("Renewing lease: {} for {}s", leaseId, incrementSeconds);

        // Build the renew request payload
        Map<String, Object> renewRequest = Map.of(
                "lease_id", leaseId,
                "increment", incrementSeconds
        );

        // Call sys/leases/renew
        VaultResponseSupport<Map> response = vaultTemplate.write(
                "sys/leases/renew", renewRequest, Map.class
        );

        Map<String, Object> result = new HashMap<>();
        if (response != null) {
            result.put("lease_id", response.getLeaseId());
            result.put("new_lease_duration_seconds", response.getLeaseDuration());
            result.put("renewable", response.isRenewable());
        }

        log.info("Lease renewed: {} | new TTL: {}s",
                result.get("lease_id"), result.get("new_lease_duration_seconds"));

        return result;
    }

    // ── 3. Revoke a lease immediately ───────────────────────────────────────

    /**
     * Calls PUT /v1/sys/leases/revoke to immediately revoke a lease.
     *
     * When a lease is revoked:
     *  - The Vault lease record is deleted
     *  - Vault drops the PostgreSQL user immediately (via DB secrets engine)
     *  - Any open connections using that user will fail
     *
     * This is what happens automatically when the TTL expires,
     * or when the application shuts down gracefully.
     *
     * @param leaseId The full lease ID to revoke
     */
    public Map<String, Object> revokeLease(String leaseId) {
        log.warn("Revoking lease immediately: {}", leaseId);

        vaultTemplate.write("sys/leases/revoke", Map.of("lease_id", leaseId), Map.class);

        log.warn("Lease revoked: {} — DB user has been dropped in PostgreSQL", leaseId);

        return Map.of(
                "status", "revoked",
                "lease_id", leaseId,
                "message", "DB user dropped immediately in PostgreSQL"
        );
    }

    // ── 4. Look up lease metadata ────────────────────────────────────────────

    /**
     * Calls PUT /v1/sys/leases/lookup to inspect a lease without renewing it.
     *
     * Returns: issue_time, expire_time, renewable, ttl remaining
     */
    public Map<String, Object> lookupLease(String leaseId) {
        log.info("Looking up lease: {}", leaseId);

        VaultResponseSupport<Map> response = vaultTemplate.write(
                "sys/leases/lookup", Map.of("lease_id", leaseId), Map.class
        );

        if (response == null || response.getData() == null) {
            return Map.of("error", "Lease not found or already expired: " + leaseId);
        }

        return new HashMap<>(response.getData());
    }
}
